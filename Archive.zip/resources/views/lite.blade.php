@extends('layouts.app')

@section('content')
    <test-component></test-component>
@endsection
